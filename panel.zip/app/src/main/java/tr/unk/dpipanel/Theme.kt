package tr.unk.dpipanel

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object Pal {
    val Ok = Color(0xFF3DDC97)
    val Warn = Color(0xFFFFC857)
    val Bad = Color(0xFFFF6B6B)
}

private val DarkColors = darkColorScheme(
    primary = Color(0xFF3DDC97),
    onPrimary = Color(0xFF00210F),
    primaryContainer = Color(0xFF0F3A2A),
    onPrimaryContainer = Color(0xFFB7F5D6),
    secondary = Color(0xFF8AB4FF),
    background = Color(0xFF0B0F14),
    onBackground = Color(0xFFE6EDF3),
    surface = Color(0xFF0B0F14),
    onSurface = Color(0xFFE6EDF3),
    surfaceVariant = Color(0xFF151C26),
    onSurfaceVariant = Color(0xFF9AA7B5),
    outline = Color(0xFF2A3441),
    outlineVariant = Color(0xFF1F2833),
    error = Color(0xFFFF6B6B),
    errorContainer = Color(0xFF3A1717),
    onErrorContainer = Color(0xFFFFB4B4),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF0A8F5C),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFD3F5E5),
    onPrimaryContainer = Color(0xFF00391F),
    secondary = Color(0xFF2F5FD0),
    background = Color(0xFFF4F6F9),
    onBackground = Color(0xFF11161C),
    surface = Color(0xFFF4F6F9),
    onSurface = Color(0xFF11161C),
    surfaceVariant = Color(0xFFFFFFFF),
    onSurfaceVariant = Color(0xFF5B6773),
    outline = Color(0xFFD5DBE3),
    outlineVariant = Color(0xFFE6EAF0),
    error = Color(0xFFD93A3A),
    errorContainer = Color(0xFFFFE3E3),
    onErrorContainer = Color(0xFF5C0D0D),
)

private val PanelTypography = Typography(
    headlineMedium = TextStyle(
        fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 34.sp, letterSpacing = (-0.5).sp,
    ),
    headlineSmall = TextStyle(
        fontWeight = FontWeight.Bold, fontSize = 22.sp, lineHeight = 28.sp, letterSpacing = (-0.3).sp,
    ),
    titleMedium = TextStyle(
        fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp,
    ),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    labelLarge = TextStyle(
        fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 20.sp,
    ),
)

private val PanelShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun PanelTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        typography = PanelTypography,
        shapes = PanelShapes,
        content = content,
    )
}
