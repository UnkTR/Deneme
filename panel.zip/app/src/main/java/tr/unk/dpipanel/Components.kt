package tr.unk.dpipanel

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ------------------------------------------------------------ kartlar

@Composable
fun SurfaceCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val shape = RoundedCornerShape(24.dp)
    val base = modifier
        .fillMaxWidth()
        .clip(shape)
        .background(MaterialTheme.colorScheme.surfaceVariant)
        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, shape)
    Column(
        modifier = (if (onClick != null) base.clickable(onClick = onClick) else base)
            .padding(18.dp),
        content = content,
    )
}

@Composable
fun StatCard(
    value: Int,
    label: String,
    accent: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier = modifier
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
    ) {
        Box(
            Modifier
                .width(22.dp)
                .height(4.dp)
                .background(accent, RoundedCornerShape(2.dp))
        )
        Spacer(Modifier.height(10.dp))
        Text(
            value.toString(),
            fontSize = 30.sp,
            lineHeight = 34.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
        )
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/** state: 1 iyi, 0 kotu, -1 notr */
@Composable
fun StatusChip(label: String, state: Int) {
    val color = when (state) {
        1 -> Pal.Ok
        0 -> Pal.Bad
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    Row(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.14f))
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(7.dp).background(color, CircleShape))
        Spacer(Modifier.width(7.dp))
        Text(
            label,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = color,
        )
    }
}

// ------------------------------------------------------------ guc dugmesi

@Composable
fun PowerButton(level: Level, busy: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val accent by animateColorAsState(
        when (level) {
            Level.On -> Pal.Ok
            Level.Partial -> Pal.Warn
            Level.Off -> cs.onSurfaceVariant
        },
        label = "accent",
    )
    val t = rememberInfiniteTransition(label = "power")
    val ring by t.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2400, easing = LinearEasing), RepeatMode.Restart),
        label = "ring",
    )
    val rot by t.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(1100, easing = LinearEasing), RepeatMode.Restart),
        label = "rot",
    )
    val glyph = if (level == Level.Off) cs.onSurfaceVariant else Color(0xFF04281A)
    val fill = when (level) {
        Level.On -> Brush.linearGradient(listOf(Color(0xFF5CF0B0), Color(0xFF20C7B0)))
        Level.Partial -> Brush.linearGradient(listOf(Color(0xFFFFD36E), Color(0xFFFFA94D)))
        Level.Off -> Brush.linearGradient(listOf(cs.surfaceVariant, cs.surfaceVariant))
    }

    Box(Modifier.size(250.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension * 0.30f
            val c = center
            if (level == Level.On && !busy) {
                for (k in 0..1) {
                    val p = (ring + k * 0.5f) % 1f
                    drawCircle(
                        color = accent.copy(alpha = (1f - p) * 0.30f),
                        radius = r + p * size.minDimension * 0.17f,
                        center = c,
                        style = Stroke(width = 3.dp.toPx()),
                    )
                }
            }
            drawCircle(color = accent.copy(alpha = 0.10f), radius = r * 1.32f, center = c)
            drawCircle(
                color = accent.copy(alpha = 0.22f),
                radius = r * 1.14f,
                center = c,
                style = Stroke(width = 1.5.dp.toPx()),
            )
            if (busy) {
                val rr = r * 1.14f
                drawArc(
                    color = accent,
                    startAngle = rot,
                    sweepAngle = 110f,
                    useCenter = false,
                    topLeft = Offset(c.x - rr, c.y - rr),
                    size = Size(rr * 2, rr * 2),
                    style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round),
                )
            }
        }
        Box(
            Modifier
                .size(150.dp)
                .clip(CircleShape)
                .background(fill)
                .border(1.dp, accent.copy(alpha = 0.35f), CircleShape)
                .clickable(enabled = enabled, onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.size(58.dp)) {
                val sw = 6.dp.toPx()
                val d = size.minDimension
                val pad = sw / 2
                drawArc(
                    color = glyph,
                    startAngle = -55f,
                    sweepAngle = 290f,
                    useCenter = false,
                    topLeft = Offset(pad, pad + d * 0.06f),
                    size = Size(d - 2 * pad, d - 2 * pad - d * 0.06f),
                    style = Stroke(width = sw, cap = StrokeCap.Round),
                )
                drawLine(
                    color = glyph,
                    start = Offset(d / 2, pad),
                    end = Offset(d / 2, d * 0.50f),
                    strokeWidth = sw,
                    cap = StrokeCap.Round,
                )
            }
        }
    }
}

// ------------------------------------------------------------ gezinme

data class NavTab(val label: String, val icon: ImageVector)

@Composable
fun FloatingNav(tabs: List<NavTab>, selected: Int, learned: Int, onSelect: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(30.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp, vertical = 12.dp),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(cs.surfaceVariant)
                .border(1.dp, cs.outlineVariant, shape)
                .padding(6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            tabs.forEachIndexed { i, tab ->
                val sel = i == selected
                val bg by animateColorAsState(
                    if (sel) cs.primary.copy(alpha = 0.16f) else Color.Transparent,
                    label = "navbg",
                )
                val fg by animateColorAsState(
                    if (sel) cs.primary else cs.onSurfaceVariant,
                    label = "navfg",
                )
                Row(
                    Modifier
                        .clip(RoundedCornerShape(24.dp))
                        .background(bg)
                        .clickable { onSelect(i) }
                        .padding(horizontal = 18.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (i == 1 && learned > 0) {
                        BadgedBox(badge = { Badge { Text(learned.toString()) } }) {
                            Icon(tab.icon, null, tint = fg)
                        }
                    } else {
                        Icon(tab.icon, null, tint = fg)
                    }
                    AnimatedVisibility(visible = sel) {
                        Row {
                            Spacer(Modifier.width(8.dp))
                            Text(
                                tab.label,
                                color = fg,
                                style = MaterialTheme.typography.labelLarge,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(18.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(cs.surfaceVariant)
            .border(1.dp, cs.outlineVariant, shape)
            .padding(4.dp),
    ) {
        options.forEachIndexed { i, label ->
            val sel = i == selected
            val bg by animateColorAsState(
                if (sel) cs.primary.copy(alpha = 0.18f) else Color.Transparent,
                label = "segbg",
            )
            val fg by animateColorAsState(
                if (sel) cs.primary else cs.onSurfaceVariant,
                label = "segfg",
            )
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(bg)
                    .clickable { onSelect(i) }
                    .padding(vertical = 11.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(label, color = fg, style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}

// ------------------------------------------------------------ listeler

private val AvatarColors = listOf(
    Color(0xFF3DDC97), Color(0xFF8AB4FF), Color(0xFFFFC857),
    Color(0xFFFF8FA3), Color(0xFFB69CFF), Color(0xFF5CE1E6),
)

@Composable
fun DomainAvatar(domain: String) {
    val color = AvatarColors[(domain.hashCode() and 0x7fffffff) % AvatarColors.size]
    Box(
        Modifier
            .size(42.dp)
            .background(color.copy(alpha = 0.16f), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            domain.take(1).uppercase(),
            color = color,
            fontWeight = FontWeight.Bold,
            fontSize = 17.sp,
        )
    }
}

@Composable
fun DomainRow(
    domain: String,
    subtitle: String? = null,
    trailing: @Composable RowScope.() -> Unit,
) {
    val shape = RoundedCornerShape(20.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, shape)
            .padding(start = 12.dp, end = 6.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        DomainAvatar(domain)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                domain,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (subtitle != null) {
                Text(
                    subtitle,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        trailing()
    }
}

@Composable
fun EmptyState(icon: ImageVector, title: String, text: String, modifier: Modifier = Modifier) {
    Column(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 32.dp, vertical = 56.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            Modifier
                .size(72.dp)
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f), CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.height(18.dp))
        Text(
            title,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
fun InfoNote(text: String, modifier: Modifier = Modifier, onClick: (() -> Unit)? = null) {
    val shape = RoundedCornerShape(18.dp)
    val base = modifier
        .fillMaxWidth()
        .clip(shape)
        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.10f))
        .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.22f), shape)
    Row(
        (if (onClick != null) base.clickable(onClick = onClick) else base).padding(14.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Icon(
            Icons.Filled.Info,
            null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp),
        )
        Spacer(Modifier.width(10.dp))
        Text(
            text,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
        )
    }
}
