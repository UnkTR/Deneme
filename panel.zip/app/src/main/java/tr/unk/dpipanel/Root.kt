package tr.unk.dpipanel

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class ShResult(val out: String, val code: Int) {
    val ok: Boolean get() = code == 0
}

object Root {
    /** Komutu `su -c` ile root olarak calistirir. */
    suspend fun sh(cmd: String): ShResult = withContext(Dispatchers.IO) {
        try {
            val p = ProcessBuilder("su", "-c", cmd)
                .redirectErrorStream(true)
                .start()
            val out = p.inputStream.bufferedReader().readText()
            val code = p.waitFor()
            ShResult(out.trim(), code)
        } catch (e: Exception) {
            ShResult(e.message ?: "su hatasi", 127)
        }
    }
}
