package tr.unk.dpipanel

import android.content.Context
import android.content.SharedPreferences
import android.util.Log

/** Uygulama beklenmedik sekilde kapanirsa nedenini bir sonraki acilista gostermek icin. */
object Diag {
    private var prefs: SharedPreferences? = null

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("diag", Context.MODE_PRIVATE)
    }

    fun mark(action: String) {
        prefs?.edit()?.putString("action", action)?.commit()
    }

    fun clearMark() {
        prefs?.edit()?.remove("action")?.commit()
    }

    fun saveCrash(t: Throwable) {
        prefs?.edit()?.putString("crash", Log.getStackTraceString(t).take(1800))?.commit()
    }

    fun takeReport(): String? {
        val p = prefs ?: return null
        val crash = p.getString("crash", null)
        val action = p.getString("action", null)
        p.edit().clear().commit()
        return when {
            crash != null -> "Uygulama çöktü:\n$crash"
            action != null -> "Son işlem bitmeden uygulama kapandı: $action"
            else -> null
        }
    }
}
