package tr.unk.dpipanel

object P {
    const val MOD = "/data/adb/modules/discord_dpi"
    const val LISTS = "/data/local/tmp/discord_dpi_lists"
    const val AH = "$LISTS/autohostlist.txt"
    const val EH = "$LISTS/exclude-hosts.txt"
    const val EU = "$LISTS/exclude-user.txt"
    const val UH_MOD = "$MOD/lists/user-hosts.txt"
    const val SVC = "$MOD/service.sh"
    const val UNINST = "$MOD/uninstall.sh"
    const val LOG = "$MOD/log/service.log"
}

data class Snapshot(
    val rootOk: Boolean,
    val moduleOk: Boolean,
    val nfqws: Boolean,
    val dns: Boolean,
    val rules: Boolean,
    val ttl: Boolean,
    val learned: List<String>,
    val userExclude: List<String>,
    val allExclude: List<String>,
    val userHosts: List<String>,
    val log: String,
)

object Repo {

    private val DOMAIN = Regex("^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$")

    /** "https://www.Ornek.com/yol?x" -> "ornek.com" ; gecersizse null */
    fun normalize(raw: String): String? {
        var s = raw.trim().lowercase()
        s = s.removePrefix("http://").removePrefix("https://")
        s = s.substringBefore('/').substringBefore('?').substringBefore('#')
        s = s.substringAfter('@')
        s = s.substringBefore(':')
        s = s.removePrefix("*.").removePrefix("www.").trimEnd('.')
        return if (DOMAIN.matches(s)) s else null
    }

    /** Birden fazla alan adi iceren metni ayristirir (bosluk, virgul, satir). */
    fun parseInput(text: String): List<String> =
        text.split(Regex("[\\s,;]+"))
            .filter { it.isNotBlank() }
            .mapNotNull { normalize(it) }
            .distinct()

    private fun clean(lines: List<String>): List<String> =
        lines.map { it.trim() }
            .filter { it.isNotEmpty() && !it.startsWith("#") }
            .distinct()

    private fun sections(text: String): Map<String, List<String>> {
        val m = LinkedHashMap<String, MutableList<String>>()
        var cur: MutableList<String>? = null
        for (line in text.lines()) {
            if (line.startsWith("##")) {
                cur = mutableListOf()
                m[line.substring(2).trim()] = cur
            } else {
                cur?.add(line)
            }
        }
        return m
    }

    suspend fun snapshot(): Snapshot {
        val cmd = """
            echo '##ROOT'; id -u
            echo '##MOD'; [ -d ${P.MOD} ] && echo 1 || echo 0
            echo '##NFQWS'; pidof nfqws2 >/dev/null 2>&1 && echo 1 || echo 0
            echo '##DNS'; pidof dnsproxy >/dev/null 2>&1 && echo 1 || echo 0
            echo '##RULES'; iptables -t mangle -S 2>/dev/null | grep -c DPI_TR
            echo '##TTL'; iptables -t mangle -S 2>/dev/null | grep -c nfqttl
            echo '##AH'; cat ${P.AH} 2>/dev/null
            echo '##EH'; cat ${P.EH} 2>/dev/null
            echo '##EU'; cat ${P.EU} 2>/dev/null
            echo '##UH'; cat ${P.UH_MOD} 2>/dev/null
            echo '##LOG'; tail -n 80 ${P.LOG} 2>/dev/null
            echo '##END'
        """.trimIndent()
        val r = Root.sh(cmd)
        val s = sections(r.out)
        fun one(k: String) = s[k]?.firstOrNull { it.isNotBlank() }?.trim()
        val rootOk = one("ROOT") == "0"
        if (!rootOk) {
            return Snapshot(false, false, false, false, false, false,
                emptyList(), emptyList(), emptyList(), emptyList(), r.out)
        }
        val eu = clean(s["EU"].orEmpty())
        return Snapshot(
            rootOk = true,
            moduleOk = one("MOD") == "1",
            nfqws = one("NFQWS") == "1",
            dns = one("DNS") == "1",
            rules = (one("RULES")?.toIntOrNull() ?: 0) > 0,
            ttl = (one("TTL")?.toIntOrNull() ?: 0) > 0,
            learned = clean(s["AH"].orEmpty()).reversed(),
            userExclude = eu,
            allExclude = clean(s["EH"].orEmpty()),
            userHosts = clean(s["UH"].orEmpty()),
            log = s["LOG"].orEmpty().joinToString("\n").trim(),
        )
    }

    // Eski service.sh'ta "refresh" komutu yoksa calistirma (varsayilan dal servisi yeniden baslatirdi)
    private const val REFRESH = "grep -q 'refresh)' ${P.SVC} && sh ${P.SVC} refresh >/dev/null 2>&1"

    /** Dosyaya (satir basina bir alan adi) ekler, sonra listeleri yeniler. */
    suspend fun add(file: String, domains: List<String>): ShResult {
        val list = domains.joinToString(" ")
        val cmd = "touch $file; " +
            "[ -n \"\$(tail -c1 $file)\" ] && echo >> $file; " +
            "for d in $list; do grep -qxF \"\$d\" $file || echo \"\$d\" >> $file; done; " +
            REFRESH
        return Root.sh(cmd)
    }

    /** Dosyadan tam eslesen satiri siler (dosya sahibi/izni korunur), sonra yeniler. */
    suspend fun remove(file: String, domain: String): ShResult {
        val cmd = "grep -vxF -- \"$domain\" $file > $file.tmp; " +
            "cat $file.tmp > $file; rm -f $file.tmp; " +
            REFRESH
        return Root.sh(cmd)
    }

    suspend fun clearLearned(): ShResult =
        Root.sh(": > ${P.AH}; $REFRESH")

    suspend fun refreshLists(): ShResult = Root.sh(REFRESH)

    /** Excludeler listeye eklenir; refresh autohostlist'ten de siler. */
    suspend fun excludeLearned(domain: String): ShResult = add(P.EU, listOf(domain))

    suspend fun start(): ShResult =
        Root.sh("sh ${P.SVC} >/dev/null 2>&1 </dev/null")

    suspend fun stop(): ShResult =
        Root.sh("sh ${P.UNINST} >/dev/null 2>&1 </dev/null")
}
