@file:OptIn(ExperimentalMaterial3Api::class)

package tr.unk.dpipanel

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

// ---------------------------------------------------------------- kok

@Composable
fun PanelApp(vm: PanelViewModel) {
    val st by vm.state.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val snack = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        vm.events.collect { snack.showSnackbar(it) }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            if (st.rootOk == true) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 0.dp,
                ) {
                    NavigationBarItem(
                        selected = tab == 0,
                        onClick = { tab = 0 },
                        icon = { Icon(Icons.Filled.Home, null) },
                        label = { Text("Durum") },
                    )
                    NavigationBarItem(
                        selected = tab == 1,
                        onClick = { tab = 1 },
                        icon = {
                            if (st.learned.isNotEmpty()) {
                                BadgedBox(badge = { Badge { Text(st.learned.size.toString()) } }) {
                                    Icon(Icons.Filled.Search, null)
                                }
                            } else {
                                Icon(Icons.Filled.Search, null)
                            }
                        },
                        label = { Text("Öğrenilen") },
                    )
                    NavigationBarItem(
                        selected = tab == 2,
                        onClick = { tab = 2 },
                        icon = { Icon(Icons.Filled.List, null) },
                        label = { Text("Listeler") },
                    )
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when {
                st.rootOk == null -> Loading()
                st.rootOk == false -> NoRoot(onRetry = { vm.refresh(true) })
                tab == 0 -> StatusScreen(st, vm)
                tab == 1 -> LearnedScreen(st, vm)
                else -> ListsScreen(st, vm)
            }
        }
    }
}

@Composable
private fun Loading() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(strokeWidth = 3.dp)
            Spacer(Modifier.height(16.dp))
            Text(
                "Root izni bekleniyor…",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun NoRoot(onRetry: () -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            EmptyState(
                Icons.Filled.Warning,
                "Root izni verilmedi",
                "Magisk açılan pencerede süper kullanıcı iznini onayla. " +
                    "Daha önce reddettiysen Magisk > Süper kullanıcı bölümünden izin ver.",
            )
            Button(onClick = onRetry) { Text("Tekrar dene") }
        }
    }
}

// ---------------------------------------------------------------- durum

@Composable
fun StatusScreen(st: PanelState, vm: PanelViewModel) {
    var logOpen by rememberSaveable { mutableStateOf(false) }
    val idle = st.busy == null

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Column(Modifier.padding(top = 8.dp)) {
                Text(
                    "DPI Panel",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                Text(
                    "zapret2 · nfqws2 · DoH",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        if (!st.moduleOk) {
            item {
                InfoNote("discord_dpi modülü bulunamadı. Magisk'te modülün kurulu ve açık olduğundan emin ol.")
            }
        }

        item { Hero(st, vm) }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile(st.learned.size, "Öğrenilen", Modifier.weight(1f))
                StatTile(st.userExclude.size + st.builtinExclude.size, "Hariç", Modifier.weight(1f))
                StatTile(st.userHosts.size, "Zorunlu", Modifier.weight(1f))
            }
        }

        item {
            SurfaceCard {
                Text(
                    "Bileşenler",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Spacer(Modifier.height(4.dp))
                StatusRow("nfqws2 · DPI bypass", if (st.nfqws) "çalışıyor" else "durdu", if (st.nfqws) 1 else 0)
                StatusRow("dnsproxy · DoH DNS", if (st.dns) "çalışıyor" else "durdu", if (st.dns) 1 else 0)
                StatusRow("iptables kuralları", if (st.rules) "yüklü" else "yok", if (st.rules) 1 else 0)
                StatusRow("nfqttl · hotspot TTL", if (st.ttl) "algılandı" else "bulunamadı", if (st.ttl) 1 else -1)
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = { vm.refreshLists() },
                    enabled = idle && st.moduleOk,
                    modifier = Modifier.weight(1f).height(48.dp),
                    shape = RoundedCornerShape(14.dp),
                ) {
                    Icon(Icons.Filled.Refresh, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Listeleri yenile")
                }
                OutlinedButton(
                    onClick = { vm.restart() },
                    enabled = idle && st.moduleOk,
                    modifier = Modifier.weight(1f).height(48.dp),
                    shape = RoundedCornerShape(14.dp),
                ) {
                    Text("Yeniden başlat")
                }
            }
        }

        item {
            SurfaceCard {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { logOpen = !logOpen },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        "Servis günlüğü",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f),
                    )
                    Icon(
                        if (logOpen) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                        null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (logOpen) {
                    Spacer(Modifier.height(10.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .heightIn(max = 260.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.background)
                            .padding(10.dp)
                            .verticalScroll(rememberScrollState()),
                    ) {
                        Text(
                            if (st.log.isBlank()) "Günlük boş." else st.log,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            lineHeight = 15.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Hero(st: PanelState, vm: PanelViewModel) {
    val cs = MaterialTheme.colorScheme
    val color = when (st.level) {
        Level.On -> Pal.Ok
        Level.Partial -> Pal.Warn
        Level.Off -> cs.onSurfaceVariant
    }
    val title = when (st.level) {
        Level.On -> "Koruma aktif"
        Level.Partial -> "Kısmen çalışıyor"
        Level.Off -> "Koruma kapalı"
    }
    val sub = when (st.level) {
        Level.On -> "DPI bypass ve DoH DNS çalışıyor"
        Level.Partial -> "Bazı bileşenler eksik, yeniden başlat"
        Level.Off -> "Kurallar yüklü değil"
    }
    val shape = RoundedCornerShape(28.dp)
    val bg = if (st.level == Level.On) {
        Brush.linearGradient(listOf(cs.primaryContainer, cs.surfaceVariant))
    } else {
        Brush.linearGradient(listOf(cs.surfaceVariant, cs.surfaceVariant))
    }

    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(bg)
            .border(1.dp, color.copy(alpha = 0.28f), shape)
            .padding(20.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            PulseDot(color, st.level == Level.On && st.busy == null)
            Spacer(Modifier.width(6.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    title,
                    style = MaterialTheme.typography.headlineSmall,
                    color = cs.onSurface,
                )
                Text(
                    sub,
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant,
                )
            }
        }
        Spacer(Modifier.height(18.dp))
        Button(
            onClick = { if (st.level == Level.Partial) vm.restart() else vm.toggle() },
            enabled = st.busy == null && st.moduleOk,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(16.dp),
            colors = if (st.level == Level.Off) {
                ButtonDefaults.buttonColors()
            } else {
                ButtonDefaults.buttonColors(
                    containerColor = cs.background.copy(alpha = 0.55f),
                    contentColor = cs.onSurface,
                )
            },
        ) {
            if (st.busy != null) {
                CircularProgressIndicator(
                    Modifier.size(20.dp),
                    strokeWidth = 2.dp,
                    color = LocalContentColor.current,
                )
                Spacer(Modifier.width(10.dp))
                Text(st.busy)
            } else {
                Icon(
                    if (st.level == Level.Off) Icons.Filled.PlayArrow else Icons.Filled.Close,
                    null,
                    Modifier.size(20.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    when (st.level) {
                        Level.Off -> "Başlat"
                        Level.Partial -> "Yeniden başlat"
                        Level.On -> "Durdur"
                    },
                )
            }
        }
    }
}

// ---------------------------------------------------------------- ogrenilen

@Composable
fun LearnedScreen(st: PanelState, vm: PanelViewModel) {
    var confirmClear by remember { mutableStateOf(false) }
    val n = st.learned.size
    val idle = st.busy == null

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 8.dp, top = 16.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    "Öğrenilen siteler",
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                Text(
                    "$n site · otomatik tespit",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (n > 0) {
                IconButton(onClick = { confirmClear = true }, enabled = idle) {
                    Icon(Icons.Filled.Delete, "Hepsini temizle")
                }
            }
            IconButton(onClick = { vm.refresh(true) }) {
                Icon(Icons.Filled.Refresh, "Yenile")
            }
        }

        if (n == 0) {
            EmptyState(
                Icons.Filled.Search,
                "Henüz öğrenilen site yok",
                "Engelli bir siteyi açmayı dene. Birkaç denemede nfqws2 engeli fark edip siteyi buraya ekler.",
            )
        } else {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 24.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                item {
                    InfoNote(
                        "Normalde zaten açılan bir site görürsen “Hariç tut”a bas. " +
                            "O site bir daha bypass almaz ve tekrar öğrenilmez.",
                    )
                    Spacer(Modifier.height(4.dp))
                }
                items(st.learned, key = { it }) { d ->
                    DomainRow(d, "otomatik öğrenildi") {
                        TextButton(onClick = { vm.excludeLearned(d) }, enabled = idle) {
                            Icon(Icons.Filled.Check, null, Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Hariç tut")
                        }
                        IconButton(onClick = { vm.removeLearned(d) }, enabled = idle) {
                            Icon(Icons.Filled.Delete, "Listeden sil")
                        }
                    }
                }
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Öğrenilenleri temizle?") },
            text = {
                Text("Liste boşaltılır. Engelli siteler tekrar açılmaya çalışıldığında yeniden öğrenilir.")
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmClear = false
                    vm.clearLearned()
                }) { Text("Temizle") }
            },
            dismissButton = {
                TextButton(onClick = { confirmClear = false }) { Text("Vazgeç") }
            },
        )
    }
}

// ---------------------------------------------------------------- listeler

@Composable
fun ListsScreen(st: PanelState, vm: PanelViewModel) {
    var seg by rememberSaveable { mutableIntStateOf(0) }
    var input by rememberSaveable { mutableStateOf("") }
    var showBuiltin by rememberSaveable { mutableStateOf(false) }
    val idle = st.busy == null

    val q = input.trim().lowercase()
    val own = if (seg == 0) st.userExclude else st.userHosts
    val builtin = if (seg == 0) st.builtinExclude else emptyList()
    val ownShown = if (q.isEmpty()) own else own.filter { it.contains(q) }
    val builtinShown = if (q.isEmpty()) builtin else builtin.filter { it.contains(q) }
    val builtinVisible = showBuiltin || q.isNotEmpty()

    val submit: () -> Unit = {
        if (input.isNotBlank()) {
            if (seg == 0) vm.addExclude(input) else vm.addUserHosts(input)
            input = ""
        }
    }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp)) {
            Text(
                "Listeler",
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onBackground,
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = seg == 0,
                    onClick = { seg = 0 },
                    label = { Text("Hariç tutulan") },
                )
                FilterChip(
                    selected = seg == 1,
                    onClick = { seg = 1 },
                    label = { Text("Her zaman bypass") },
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                if (seg == 0) "Bu sitelere bypass uygulanmaz ve otomatik öğrenmeye eklenmez."
                else "Bu siteler engelli olmasa bile her zaman bypass alır.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    placeholder = { Text("Alan adı yaz veya yapıştır") },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Uri,
                        imeAction = ImeAction.Done,
                    ),
                    keyboardActions = KeyboardActions(onDone = { submit() }),
                    trailingIcon = {
                        if (input.isNotEmpty()) {
                            IconButton(onClick = { input = "" }) {
                                Icon(Icons.Filled.Close, "Temizle")
                            }
                        }
                    },
                )
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = submit,
                    enabled = input.isNotBlank() && idle,
                    modifier = Modifier.size(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    contentPadding = PaddingValues(0.dp),
                ) {
                    Icon(Icons.Filled.Add, "Ekle")
                }
            }
            Text(
                "Birden fazla alan adını boşluk veya satırla ayırarak yapıştırabilirsin. " +
                    "Yazarken liste filtrelenir.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 8.dp, bottom = 4.dp),
            )
        }

        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item {
                Text(
                    if (seg == 0) "Senin eklediklerin · ${ownShown.size}" else "Eklenenler · ${ownShown.size}",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            if (ownShown.isEmpty()) {
                item {
                    Text(
                        if (own.isEmpty()) "Henüz bir şey eklemedin." else "Eşleşen kayıt yok.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            items(ownShown, key = { "o$it" }) { d ->
                DomainRow(d) {
                    IconButton(
                        onClick = { if (seg == 0) vm.removeExclude(d) else vm.removeUserHost(d) },
                        enabled = idle,
                    ) {
                        Icon(Icons.Filled.Delete, "Sil")
                    }
                }
            }

            if (seg == 0) {
                item {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(top = 12.dp)
                            .clickable { showBuiltin = !showBuiltin },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            "Yerleşik liste · ${builtinShown.size}",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.weight(1f),
                        )
                        Icon(
                            if (builtinVisible) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                            null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                if (builtinVisible) {
                    items(builtinShown, key = { "b$it" }) { d ->
                        DomainRow(d, "yerleşik") {
                            Icon(
                                Icons.Filled.Lock,
                                null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(end = 12.dp).size(18.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}
