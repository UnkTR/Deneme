@file:OptIn(ExperimentalMaterial3Api::class)

package tr.unk.dpipanel

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

private val Tabs = listOf(
    NavTab("Durum", Icons.Filled.Home),
    NavTab("Öğrenilen", Icons.Filled.Search),
    NavTab("Listeler", Icons.Filled.List),
)

// ---------------------------------------------------------------- kok

@Composable
fun PanelApp(vm: PanelViewModel, startReport: String? = null) {
    val st by vm.state.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var report by rememberSaveable { mutableStateOf(startReport) }
    val snack = remember { SnackbarHostState() }
    val cs = MaterialTheme.colorScheme

    LaunchedEffect(Unit) {
        vm.events.collect { snack.showSnackbar(it) }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(cs.background)
            .background(
                Brush.verticalGradient(
                    listOf(cs.primary.copy(alpha = 0.10f), Color.Transparent),
                    endY = 1100f,
                ),
            ),
    ) {
        Scaffold(
            containerColor = Color.Transparent,
            snackbarHost = { SnackbarHost(snack) },
            bottomBar = {
                if (st.rootOk == true) {
                    FloatingNav(Tabs, tab, st.learned.size) { tab = it }
                }
            },
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when {
                    st.rootOk == null -> Loading()
                    st.rootOk == false -> NoRoot(onRetry = { vm.refresh(true) })
                    else -> Crossfade(targetState = tab, label = "tabs") { t ->
                        when (t) {
                            0 -> StatusScreen(
                                st, vm,
                                report = report,
                                onDismissReport = { report = null },
                                onNavigate = { tab = it },
                            )
                            1 -> LearnedScreen(st, vm)
                            else -> ListsScreen(st, vm)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Loading() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(strokeWidth = 3.dp)
            Spacer(Modifier.height(16.dp))
            Text(
                "Root izni bekleniyor…",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun NoRoot(onRetry: () -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            EmptyState(
                Icons.Filled.Warning,
                "Root izni verilmedi",
                "Magisk açılan pencerede süper kullanıcı iznini onayla. " +
                    "Daha önce reddettiysen Magisk > Süper kullanıcı bölümünden izin ver.",
            )
            OutlinedButton(onClick = onRetry) { Text("Tekrar dene") }
        }
    }
}

@Composable
private fun ScreenTitle(title: String, subtitle: String, actions: @Composable () -> Unit = {}) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 10.dp, top = 18.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                title,
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground,
            )
            Text(
                subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        actions()
    }
}

// ---------------------------------------------------------------- durum

@Composable
fun StatusScreen(
    st: PanelState,
    vm: PanelViewModel,
    report: String?,
    onDismissReport: () -> Unit,
    onNavigate: (Int) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    var logOpen by rememberSaveable { mutableStateOf(false) }
    val idle = st.busy == null

    val title = when (st.level) {
        Level.On -> "Koruma aktif"
        Level.Partial -> "Kısmen çalışıyor"
        Level.Off -> "Koruma kapalı"
    }
    val sub = when {
        st.busy != null -> st.busy.orEmpty()
        st.level == Level.On -> "DPI bypass ve DoH DNS çalışıyor"
        st.level == Level.Partial -> "Bazı bileşenler eksik. Dokunarak yeniden başlat"
        else -> "Başlatmak için dokun"
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp, 8.dp, 20.dp, 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            Column(Modifier.padding(top = 10.dp)) {
                Text(
                    "DPI Panel",
                    style = MaterialTheme.typography.headlineMedium,
                    color = cs.onBackground,
                )
                Text(
                    "zapret2 · nfqws2 · DoH",
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant,
                )
            }
        }

        if (report != null) {
            item {
                InfoNote(
                    report + "\n\n(kapatmak için dokun)",
                    onClick = onDismissReport,
                )
            }
        }

        if (!st.moduleOk) {
            item {
                InfoNote("discord_dpi modülü bulunamadı. Magisk'te modülün kurulu ve açık olduğundan emin ol.")
            }
        }

        item {
            Column(
                Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                PowerButton(
                    level = st.level,
                    busy = st.busy != null,
                    enabled = idle && st.moduleOk,
                    onClick = { if (st.level == Level.Partial) vm.restart() else vm.toggle() },
                )
                Text(
                    title,
                    style = MaterialTheme.typography.headlineMedium,
                    color = cs.onBackground,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    sub,
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatusChip("DPI", if (st.nfqws) 1 else 0)
                    StatusChip("DNS", if (st.dns) 1 else 0)
                    StatusChip("Kurallar", if (st.rules) 1 else 0)
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard(st.learned.size, "Öğrenilen", Pal.Ok, Modifier.weight(1f)) { onNavigate(1) }
                StatCard(
                    st.userExclude.size + st.builtinExclude.size, "Hariç",
                    Color(0xFF8AB4FF), Modifier.weight(1f),
                ) { onNavigate(2) }
                StatCard(
                    st.userHosts.size + st.moduleHosts.size, "Zorunlu",
                    Pal.Warn, Modifier.weight(1f),
                ) { onNavigate(2) }
            }
        }

        item {
            SurfaceCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "Hotspot TTL (nfqttl)",
                            style = MaterialTheme.typography.titleMedium,
                            color = cs.onSurface,
                        )
                        Text(
                            "Bu modül nfqttl'e dokunmaz",
                            style = MaterialTheme.typography.bodyMedium,
                            color = cs.onSurfaceVariant,
                        )
                    }
                    StatusChip(if (st.ttl) "algılandı" else "bulunamadı", if (st.ttl) 1 else -1)
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(
                    onClick = { vm.refreshLists() },
                    enabled = idle && st.moduleOk,
                    modifier = Modifier.weight(1f).height(50.dp),
                    shape = RoundedCornerShape(16.dp),
                ) {
                    Icon(Icons.Filled.Refresh, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Listeleri yenile")
                }
                OutlinedButton(
                    onClick = { vm.restart() },
                    enabled = idle && st.moduleOk,
                    modifier = Modifier.weight(1f).height(50.dp),
                    shape = RoundedCornerShape(16.dp),
                ) {
                    Text("Yeniden başlat")
                }
            }
        }

        item {
            SurfaceCard(onClick = { logOpen = !logOpen }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Servis günlüğü",
                        style = MaterialTheme.typography.titleMedium,
                        color = cs.onSurface,
                        modifier = Modifier.weight(1f),
                    )
                    Icon(
                        if (logOpen) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                        null,
                        tint = cs.onSurfaceVariant,
                    )
                }
                if (logOpen) {
                    Spacer(Modifier.height(12.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .heightIn(max = 280.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(cs.background)
                            .padding(12.dp)
                            .verticalScroll(rememberScrollState()),
                    ) {
                        Text(
                            if (st.log.isBlank()) "Günlük boş." else st.log,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            lineHeight = 15.sp,
                            color = cs.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- ogrenilen

@Composable
fun LearnedScreen(st: PanelState, vm: PanelViewModel) {
    var confirmClear by remember { mutableStateOf(false) }
    val n = st.learned.size
    val idle = st.busy == null
    val cs = MaterialTheme.colorScheme

    Column(Modifier.fillMaxSize()) {
        ScreenTitle("Öğrenilen", "$n site otomatik tespit edildi") {
            if (n > 0) {
                IconButton(onClick = { confirmClear = true }, enabled = idle) {
                    Icon(Icons.Filled.Delete, "Hepsini temizle")
                }
            }
            IconButton(onClick = { vm.refresh(true) }) {
                Icon(Icons.Filled.Refresh, "Yenile")
            }
        }

        if (n == 0) {
            EmptyState(
                Icons.Filled.Search,
                "Henüz öğrenilen site yok",
                "Engelli bir siteyi açmayı dene. Birkaç denemede nfqws2 engeli fark edip siteyi buraya ekler.",
            )
        } else {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(20.dp, 8.dp, 20.dp, 24.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                item {
                    InfoNote(
                        "Normalde zaten açılan bir site görürsen “Hariç tut”a bas. " +
                            "O site bir daha bypass almaz ve tekrar öğrenilmez.",
                    )
                }
                items(st.learned, key = { it }) { d ->
                    DomainRow(d, "otomatik öğrenildi") {
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(50))
                                .background(cs.primary.copy(alpha = 0.14f))
                                .clickable(enabled = idle) { vm.excludeLearned(d) }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Filled.Check, null,
                                    tint = cs.primary, modifier = Modifier.size(14.dp),
                                )
                                Spacer(Modifier.width(5.dp))
                                Text(
                                    "Hariç tut",
                                    color = cs.primary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                )
                            }
                        }
                        IconButton(onClick = { vm.removeLearned(d) }, enabled = idle) {
                            Icon(
                                Icons.Filled.Delete, "Listeden sil",
                                tint = cs.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Öğrenilenleri temizle?") },
            text = {
                Text("Liste boşaltılır. Engelli siteler tekrar açılmaya çalışıldığında yeniden öğrenilir.")
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmClear = false
                    vm.clearLearned()
                }) { Text("Temizle") }
            },
            dismissButton = {
                TextButton(onClick = { confirmClear = false }) { Text("Vazgeç") }
            },
        )
    }
}

// ---------------------------------------------------------------- listeler

@Composable
fun ListsScreen(st: PanelState, vm: PanelViewModel) {
    val cs = MaterialTheme.colorScheme
    var seg by rememberSaveable { mutableIntStateOf(0) }
    var input by rememberSaveable { mutableStateOf("") }
    var showLocked by rememberSaveable { mutableStateOf(false) }
    val idle = st.busy == null

    val q = input.trim().lowercase()
    val own = if (seg == 0) st.userExclude else st.userHosts
    val locked = if (seg == 0) st.builtinExclude else st.moduleHosts
    val ownShown = if (q.isEmpty()) own else own.filter { it.contains(q) }
    val lockedShown = if (q.isEmpty()) locked else locked.filter { it.contains(q) }
    val lockedVisible = showLocked || q.isNotEmpty()
    val lockedLabel = if (seg == 0) "Yerleşik liste" else "Modül listesi"
    val lockedTag = if (seg == 0) "yerleşik" else "modülden"

    val submit: () -> Unit = {
        if (input.isNotBlank()) {
            if (seg == 0) vm.addExclude(input) else vm.addUserHosts(input)
            input = ""
        }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenTitle("Listeler", "Hangi siteler bypass alsın, hangileri almasın")

        Column(Modifier.padding(horizontal = 20.dp)) {
            Spacer(Modifier.height(8.dp))
            Segmented(listOf("Hariç tutulan", "Her zaman bypass"), seg) { seg = it }
            Spacer(Modifier.height(10.dp))
            Text(
                if (seg == 0) "Bu sitelere bypass uygulanmaz ve otomatik öğrenmeye eklenmez."
                else "Bu siteler engelli olmasa bile her zaman bypass alır.",
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant,
            )
            Spacer(Modifier.height(12.dp))
            TextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(18.dp),
                placeholder = { Text("Alan adı yaz veya yapıştır") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                trailingIcon = {
                    if (input.isNotBlank()) {
                        Box(
                            Modifier
                                .padding(end = 8.dp)
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(cs.primary)
                                .clickable(enabled = idle) { submit() },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Filled.Add, "Ekle", tint = cs.onPrimary)
                        }
                    }
                },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Uri,
                    imeAction = ImeAction.Done,
                ),
                keyboardActions = KeyboardActions(onDone = { submit() }),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = cs.surfaceVariant,
                    unfocusedContainerColor = cs.surfaceVariant,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    disabledIndicatorColor = Color.Transparent,
                ),
            )
            Text(
                "Birden fazla alan adını boşluk veya satırla ayırarak yapıştırabilirsin. " +
                    "Yazarken liste filtrelenir.",
                fontSize = 12.sp,
                color = cs.onSurfaceVariant,
                modifier = Modifier.padding(top = 8.dp, bottom = 4.dp),
            )
        }

        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(20.dp, 8.dp, 20.dp, 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                Text(
                    "Senin eklediklerin · ${ownShown.size}",
                    style = MaterialTheme.typography.labelLarge,
                    color = cs.primary,
                )
            }
            if (ownShown.isEmpty()) {
                item {
                    Text(
                        if (own.isEmpty()) "Henüz bir şey eklemedin." else "Eşleşen kayıt yok.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant,
                    )
                }
            }
            items(ownShown, key = { "o$it" }) { d ->
                DomainRow(d) {
                    IconButton(
                        onClick = { if (seg == 0) vm.removeExclude(d) else vm.removeUserHost(d) },
                        enabled = idle,
                    ) {
                        Icon(Icons.Filled.Delete, "Sil", tint = cs.onSurfaceVariant)
                    }
                }
            }

            if (locked.isNotEmpty()) {
                item {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(top = 10.dp)
                            .clickable { showLocked = !showLocked },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            "$lockedLabel · ${lockedShown.size}",
                            style = MaterialTheme.typography.labelLarge,
                            color = cs.primary,
                            modifier = Modifier.weight(1f),
                        )
                        Icon(
                            if (lockedVisible) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                            null,
                            tint = cs.onSurfaceVariant,
                        )
                    }
                }
                if (lockedVisible) {
                    items(lockedShown, key = { "b$it" }) { d ->
                        DomainRow(d, lockedTag) {
                            Icon(
                                Icons.Filled.Lock,
                                null,
                                tint = cs.onSurfaceVariant,
                                modifier = Modifier.padding(end = 12.dp).size(18.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}
