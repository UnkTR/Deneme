package tr.unk.dpipanel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class Level { On, Partial, Off }

data class PanelState(
    val loaded: Boolean = false,
    val rootOk: Boolean? = null,
    val moduleOk: Boolean = true,
    val nfqws: Boolean = false,
    val dns: Boolean = false,
    val rules: Boolean = false,
    val ttl: Boolean = false,
    val learned: List<String> = emptyList(),
    val userExclude: List<String> = emptyList(),
    val builtinExclude: List<String> = emptyList(),
    val userHosts: List<String> = emptyList(),
    val moduleHosts: List<String> = emptyList(),
    val log: String = "",
    val busy: String? = null,
) {
    val level: Level
        get() = when {
            nfqws && dns && rules -> Level.On
            nfqws || dns || rules -> Level.Partial
            else -> Level.Off
        }
}

class PanelViewModel : ViewModel() {

    private val _state = MutableStateFlow(PanelState())
    val state: StateFlow<PanelState> = _state.asStateFlow()

    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val events: SharedFlow<String> = _events.asSharedFlow()

    private suspend fun reload() = applySnapshot(Repo.snapshot())

    private fun applySnapshot(s: Snapshot) {
        val user = s.userExclude.toSet()
        _state.update {
            it.copy(
                loaded = true,
                rootOk = s.rootOk,
                moduleOk = s.moduleOk,
                nfqws = s.nfqws,
                dns = s.dns,
                rules = s.rules,
                ttl = s.ttl,
                learned = s.learned,
                userExclude = s.userExclude,
                builtinExclude = s.allExclude.filter { d -> d !in user },
                userHosts = s.userHosts,
                moduleHosts = s.moduleHosts,
                log = s.log,
            )
        }
    }

    /** force=false: islem sirasinda periyodik yoklama atlanir. */
    fun refresh(force: Boolean = false) {
        if (!force && _state.value.busy != null) return
        viewModelScope.launch { reload() }
    }

    private fun act(busy: String, done: String?, block: suspend () -> Unit) {
        if (_state.value.busy != null) return
        viewModelScope.launch {
            _state.update { it.copy(busy = busy) }
            Diag.mark(busy)
            try {
                block()
            } finally {
                reload()
                Diag.clearMark()
                _state.update { it.copy(busy = null) }
                if (done != null) _events.tryEmit(done)
            }
        }
    }

    fun toggle() {
        if (_state.value.level == Level.Off) start() else stop()
    }

    /** Durum kosulu saglanana kadar 2 sn arayla yoklar. */
    private suspend fun waitFor(timeoutMs: Long, cond: (Snapshot) -> Boolean): Boolean {
        var waited = 0L
        while (waited < timeoutMs) {
            delay(2000)
            waited += 2000
            val s = Repo.snapshot()
            applySnapshot(s)
            if (cond(s)) return true
        }
        return false
    }

    private suspend fun doStart() {
        Repo.start()
        val ok = waitFor(90_000) { it.nfqws && it.dns && it.rules }
        _events.tryEmit(
            if (ok) "Koruma aktif"
            else "Başlatma tamamlanmadı. Durum ekranındaki servis günlüğüne bak."
        )
    }

    private suspend fun doStop() {
        Repo.stop()
        waitFor(12_000) { !it.nfqws && !it.dns && !it.rules }
    }

    fun start() = act("Başlatılıyor…", null) { doStart() }

    fun stop() = act("Durduruluyor…", "Durduruldu") { doStop() }

    fun restart() = act("Yeniden başlatılıyor…", null) {
        doStop()
        doStart()
    }

    fun refreshLists() = act("Yenileniyor…", "Listeler yenilendi") {
        Repo.refreshLists()
    }

    fun addExclude(text: String) {
        val parsed = Repo.parseInput(text)
        if (parsed.isEmpty()) {
            _events.tryEmit("Geçerli alan adı bulunamadı"); return
        }
        val known = _state.value.let { it.userExclude + it.builtinExclude }.toSet()
        val fresh = parsed.filter { it !in known }
        if (fresh.isEmpty()) {
            _events.tryEmit("Zaten listede"); return
        }
        act("Ekleniyor…", "${fresh.size} alan adı hariç tutuldu") {
            Repo.add(P.EU, fresh)
        }
    }

    fun removeExclude(domain: String) =
        act("Siliniyor…", "$domain listeden çıkarıldı") { Repo.remove(P.EU, domain) }

    fun addUserHosts(text: String) {
        val parsed = Repo.parseInput(text)
        if (parsed.isEmpty()) {
            _events.tryEmit("Geçerli alan adı bulunamadı"); return
        }
        val known = _state.value.let { it.userHosts + it.moduleHosts }.toSet()
        val fresh = parsed.filter { it !in known }
        if (fresh.isEmpty()) {
            _events.tryEmit("Zaten listede"); return
        }
        act("Ekleniyor…", "${fresh.size} alan adı eklendi") {
            Repo.add(P.UH_USER, fresh)
        }
    }

    fun removeUserHost(domain: String) =
        act("Siliniyor…", "$domain listeden çıkarıldı") { Repo.remove(P.UH_USER, domain) }

    fun excludeLearned(domain: String) =
        act("Hariç tutuluyor…", "$domain artık bypass almayacak") { Repo.excludeLearned(domain) }

    fun removeLearned(domain: String) =
        act("Siliniyor…", "$domain öğrenilenlerden silindi") { Repo.remove(P.AH, domain) }

    fun clearLearned() =
        act("Temizleniyor…", "Öğrenilen liste temizlendi") { Repo.clearLearned() }
}
